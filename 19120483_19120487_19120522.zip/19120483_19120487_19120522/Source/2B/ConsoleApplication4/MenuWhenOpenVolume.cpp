#include "MenuWhenOpenVolume.h"
#include "Entry.h"
#include <vector>
#include "Utils.h"
#include <iostream>
#include "VolumeInfo.h"
#include <string>
#include "Console.h"

using namespace std;
void MenuWhenOpenVolume::createMenu(FILE *fp, VolumeInfo *v, vector<char> &fatTable) {
	int work = -1;
	
	while (work != 0)
	{
		system("cls");
		cout << R"(
				Chon 1 trong cac cong viec sau:
				1. Liet ke cac thu muc, tep tin co trong volume.
				2. Import 1 file/folder vao volume.
				3. Xoa 1 file khoi volume.
				4. Export 1 file/folder.
				5. Doi mat khau volume.
				0. Quay lai menu chinh.
				> Lua chon cua ban: )";
		cin >> work;
		cin.ignore();
		string sourcePath = "";
		string sourceName = "";
		string targetName = "";
		string password = "";
		vector<Entry*> entries;
		string nameForDel = "";
		string pw;
		SHA256 pw256;
		switch (work)
		{
		case 1:
			entries = Utils::listEntry(fp, v, fatTable);
			Console::Display(entries);
			Utils::ListEntryFreeMemory(entries);
			system("pause");
			break;
		case 2:
			cout << "Nhap duong dan file can import: ";
			getline(cin, sourcePath);
			cout << "Nhap ten file luu: ";
			getline(cin, targetName);
			cout << "Nhap mat khau: ";
			cin >> password;
			if (Utils::saveFileToData(fp, v, fatTable, sourcePath, targetName, password)) {
				cout << "Import file thanh cong!" << endl;
			}
			else {
				cout << "Dung luong volume khong du de import!" << endl;
			}
			system("pause");
			break;
		case 3:
			cout << "Nhap ten file can xoa: ";
			cin >> nameForDel;
			if (entries.size() == 0)
				entries = Utils::listEntry(fp, v, fatTable);
			if (Utils::deleteFile(fp, v, fatTable, nameForDel, entries)) {
				cout << "Xoa file thanh cong!" << endl;
			}
			else {
				cout << "Ten file nhap khong ton tai hoac mat khau da nhap sai!" << endl;
			}
			system("pause");
			break;
		case 4:
			if (entries.size() == 0)
				entries = Utils::listEntry(fp, v, fatTable);
			for (int i = 0; i < entries.size(); i++) {
				cout << "Name: ";
				cout << entries[i]->Name() << endl;
				cout << "Path: ";
				cout << entries[i]->Path() << endl;
				cout << '\n';
			}
			cout << "Nhap path file/folder trong volume can xuat: ";
			getline(cin, sourceName);
			cout << "Nhap path can export den: ";
			getline(cin, targetName);
			if (Utils::exportFile(fp, v, fatTable, entries, sourceName, targetName)) {
				cout << "Xuat file thanh cong!" << endl;
			}
			else {
				cout << "Ten file nhap khong ton tai hoac mat khau da nhap sai!" << endl;
			}
			system("pause");
			break;
		case 5:
			cout << "Nhap mat khau cu cua volume: "; getline(cin, pw);
			//mat khau dung
			if (v->checkPassword(pw)) {
				cout << "Nhap mat khau moi cho volume: "; getline(cin, pw);
				v->SetVolPass(pw);
				fseek(fp, 0, SEEK_SET);
				v->writeVolInfo(fp);
				cout << "Mat khau da duoc doi.\n";
			}
			else
				cout << "Sai mat khau!\n";
		case 0:
			return;
		default:
			cout << "Lua chon khong hop le!" << endl;
			break;
		}
	}
}