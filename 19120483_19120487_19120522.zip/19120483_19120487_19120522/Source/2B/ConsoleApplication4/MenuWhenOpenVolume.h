#ifndef MENU_WHEN_OPEN_VOLUME_H
#define MENU_WHEN_OPEN_VOLUME_H
#include <iostream>
#include <stdio.h>
#include"VolumeInfo.h"
#include"Entry.h"
#include<string>
#include<vector>
class MenuWhenOpenVolume {
public:
	//Tao menu sau khi mo volume
	static void createMenu(FILE *fp, VolumeInfo *v, vector<char> &fatTable);
};

#endif
