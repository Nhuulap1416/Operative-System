//tam thoi dung quan tam toi entry table.
#include <iostream>
#include <stdio.h>
#include"VolumeInfo.h"
#include"Entry.h"
#include<string>
#include<vector>
#include <stack>
#include"Utils.h"
#include "MenuWhenOpenVolume.h"
#include <direct.h>
int main()
{	
	FILE *fp = nullptr;
	string name = "";
	int work = -1;
	errno_t err;
	VolumeInfo *v;
	int size = 0;
	vector<char> fatTable;
	while (work != 0)
	{
		system("cls");
		cout << R"(
	 _  _  _____  __    __  __  __  __  ____    __  __    __    _  _    __    ___  ____  __  __  ____  _  _  ____ 
	( \/ )(  _  )(  )  (  )(  )(  \/  )( ___)  (  \/  )  /__\  ( \( )  /__\  / __)( ___)(  \/  )( ___)( \( )(_  _)
	 \  /  )(_)(  )(__  )(__)(  )    (  )__)    )    (  /(__)\  )  (  /(__)\( (_-. )__)  )    (  )__)  )  (   )(  
	  \/  (_____)(____)(______)(_/\/\_)(____)  (_/\/\_)(__)(__)(_)\_)(__)(__)\___/(____)(_/\/\_)(____)(_)\_) (__) 
       )";
		cout << R"(

				 .----------------.  .----------------.  .----------------. 
				| .--------------. || .--------------. || .--------------. |
				| |  ____  ____  | || |  ________    | || |  ________    | |
				| | |_   ||   _| | || | |_   ___ `.  | || | |_   ___ `.  | |
				| |   | |__| |   | || |   | |   `. \ | || |   | |   `. \ | |
				| |   |  __  |   | || |   | |    | | | || |   | |    | | | |
				| |  _| |  | |_  | || |  _| |___.' / | || |  _| |___.' / | |
				| | |____||____| | || | |________.'  | || | |________.'  | |
				| |              | || |              | || |              | |
				| '--------------' || '--------------' || '--------------' |
				 '----------------'  '----------------'  '----------------'                                                                                                                                                                                                       
		)";
		cout << R"(
				Chon 1 trong cac cong viec sau:
				1. Tao moi 1 volume.
				2. Mo 1 volume.
				0. Thoat chuong trinh.
				> Lua chon cua ban: )";
		cin >> work;
		cin.ignore();
		switch (work)
		{
		case 1:
			cout << "Nhap ten volume muon tao: ";
			getline(cin, name);
			cout << "Nhap kich thuoc volume(>0, theo MB): ";
			cin >> size;
			Utils::initVolume(name, size * 1024 * 1024);
			cout << "Tao volume thanh cong!" << endl;
			system("pause");
			break;
		case 2:
			cout << "Nhap ten volume muon mo: ";
			getline(cin, name);
			err = fopen_s(&fp, name.c_str(), "rb+");
			if (err == 0) {
				v = Utils::readVolumeInfo(fp);
				//Kiem tra chu ky
				if (v->Signature() != 0x00444448) {
					cout << "\nChuong trinh khong ho tro loai volume nay!";
					break;
				}
				//kiem tra mat khau trc khi mo vol
				string pw;
				cout << "Nhap mat khau cua volume muon mo: "; getline(cin, pw);
				//mat khau dung
				if (v->checkPassword(pw)) {
					fatTable = Utils::readFatTable(fp,v);
					MenuWhenOpenVolume::createMenu(fp, v, fatTable);
					fclose(fp);
				}
				else {
					cout << "Mat khau sai!!!\n";
					fclose(fp);
				}
				delete v;
			}
			else {
				cout << "Ten volume vua nhap khong ton tai!" << endl;
			}
			system("pause");
			break;
		case 0:
			if(fp)
				fclose(fp);
			work = 0;
			cout << "Cam on ban da su dung chuong trinh!" << endl;
			break;
		default:
			cout << "Lua chon khong hop le!" << endl;
			break;
		}
	}
	
	system("pause");
	return 0;
}
